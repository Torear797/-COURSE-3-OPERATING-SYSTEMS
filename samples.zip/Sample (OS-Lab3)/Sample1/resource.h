//{{NO_DEPENDENCIES}}
// ���������� ����, ��������� � Microsoft Visual C++.
// ������������ Sample1.rc
//
#define IDR_MAIN_MENU                   101
#define IDR_ACCELERATOR1                102
#define IDD_PRIORITY                    103
#define IDC_COMBOBOX_PRIORITY_CLASS     1001
#define IDC_COMBO2                      1002
#define IDC_COMBOBOX_PRIORITY           1002
#define ID_40001                        40001
#define IDC_PROCESS_RELOAD              40002
#define ID_40003                        40003
#define IDC_KILLPROCESS                 40004
#define IDC_WAITPROCESS                 40005
#define ID_VIEW_PROCESSES_IN_JOB        40009
#define ID_PROCESS_RELOAD               40010
#define ID_KILLPROCESS                  40011
#define ID_WAITPROCESS                  40012
#define ID_NEWPROCESS                   40013
#define ID_PRIORITY                     40016
#define ID_VIEW_NEWPROCESSES_IN_JOB     40017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40018
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
