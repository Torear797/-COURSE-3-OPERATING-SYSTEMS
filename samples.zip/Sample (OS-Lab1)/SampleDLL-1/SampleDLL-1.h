// SampleDLL-1.h
//
// Copyright (c), �.�. ��������� (andrei.glukhoedov@gmail.com)
//

#pragma once

#if !defined(__SAMPLE_DLL_1_H__)
#define __SAMPLE_DLL_1_H__

#ifdef SAMPLEDLL1_EXPORTS
#define SAMPLEDLL1_API __declspec(dllexport)
#else
#define SAMPLEDLL1_API __declspec(dllimport)
#endif

#include <ShlObj.h>

#ifdef __cplusplus
extern "C" {
#endif

SAMPLEDLL1_API void PrintSysDirectories(const long csidl[], unsigned long nCount);

SAMPLEDLL1_API BOOL PrintOSVersionInfo();

SAMPLEDLL1_API void PrintDataTime(LPCWSTR lpLocaleName, const SYSTEMTIME *lpDataTime, LPCWSTR lpDateFormat, LPCWSTR lpTimeFormat);

#ifdef __cplusplus
}
#endif

#endif /* __SAMPLE_DLL_1_H__ */
