// SampleDLL-1.cpp
//
// Copyright (c), �.�. ��������� (andrei.glukhoedov@gmail.com)
//

#include <Windows.h>
#include <stdio.h>
#include <tchar.h>

#include "SampleDLL-1.h"

// ------------------------------------------------------------------------------------------------
BOOL WINAPI DllMain(HINSTANCE hInstDLL, DWORD dwReason, LPVOID lpvReserved)
{
    return TRUE;
} // DllMain

// ------------------------------------------------------------------------------------------------
SAMPLEDLL1_API void PrintSysDirectories(const long csidl[], unsigned long nCount)
{
    TCHAR szBuffer[MAX_PATH + 1];

    for (unsigned long i = 0; i < nCount; ++i)
    {
        HRESULT hr = SHGetFolderPath(NULL, csidl[i], NULL, SHGFP_TYPE_CURRENT, szBuffer);

        if (S_OK == hr)
            _tprintf(TEXT("%d: %s\n"), i+1, szBuffer);
    } // for
} // PrintSysDirectories

// ------------------------------------------------------------------------------------------------
SAMPLEDLL1_API BOOL PrintOSVersionInfo()
{
    OSVERSIONINFO osVerInfo = { sizeof(OSVERSIONINFO) };
    BOOL bRet = GetVersionEx(&osVerInfo);

    if (FALSE != bRet)
    {
        _tprintf(TEXT("Version: %d.%d.%d\n"), osVerInfo.dwMajorVersion, osVerInfo.dwMinorVersion, osVerInfo.dwBuildNumber);

        switch (osVerInfo.dwMajorVersion)
        {
        case 5:
            switch (osVerInfo.dwMinorVersion)
            {
            case 1:
                _tprintf(TEXT("Windows XP"));
                break;
            case 2:
                _tprintf(TEXT("Windows Server 2003"));
                break;
            } // switch
            break;
        case 6:
            switch (osVerInfo.dwMinorVersion)
            {
            case 0:
                _tprintf(TEXT("Windows Vista"));
                break;
            case 1:
                _tprintf(TEXT("Windows 7"));
                break;
            case 2:
                _tprintf(TEXT("Windows 8"));
                break;
            case 3:
                _tprintf(TEXT("Windows 8.1"));
                break;
            } // switch
            break;
        case 10:
            switch (osVerInfo.dwMinorVersion)
            {
            case 0:
                _tprintf(TEXT("Windows 10"));
                break;
            } // switch
            break;
        } // switch

        _tprintf(TEXT(" %s\n"), osVerInfo.szCSDVersion);
    } // if

    return bRet;
} // PrintOSVersionInfo

// ------------------------------------------------------------------------------------------------
SAMPLEDLL1_API void PrintDataTime(LPCWSTR lpLocaleName, const SYSTEMTIME *lpDataTime, LPCWSTR lpDateFormat, LPCWSTR lpTimeFormat)
{
    wchar_t szDateStr[100] = L"";
    GetDateFormatEx(lpLocaleName, 0, lpDataTime, lpDateFormat, szDateStr, _countof(szDateStr), NULL);

    wchar_t szTimeStr[100] = L"";
    GetTimeFormatEx(lpLocaleName, 0, lpDataTime, lpTimeFormat, szTimeStr, _countof(szTimeStr));

    wprintf(L"%s %s\n", szDateStr, szTimeStr);
} // PrintDataTime
