// SampleDLL-3.h
//
// Copyright (c), �.�. ��������� (andrei.glukhoedov@gmail.com)
//

#pragma once

#if !defined(__SAMPLE_DLL_3_H__)
#define __SAMPLE_DLL_3_H__

#ifdef SAMPLEDLL3_EXPORTS
#define SAMPLEDLL3_API __declspec(dllexport)
#else
#define SAMPLEDLL3_API __declspec(dllimport)
#endif

#ifndef SPI_GETFLATMENU
#define SPI_GETFLATMENU                     0x1022
#endif

#ifndef SPI_GETDROPSHADOW
#define SPI_GETDROPSHADOW                   0x1024
#endif

#ifndef SPI_GETFOCUSBORDERHEIGHT
#define SPI_GETFOCUSBORDERHEIGHT            0x2010
#endif

#ifndef SPI_GETFOCUSBORDERWIDTH
#define SPI_GETFOCUSBORDERWIDTH             0x200E
#endif

#ifndef SPI_GETSERIALKEYS
#define SPI_GETSERIALKEYS                   0x003E
#endif

#ifndef SPI_GETCONTACTVISUALIZATION
#define SPI_GETCONTACTVISUALIZATION         0x2018
#endif

#ifndef SPI_GETGESTUREVISUALIZATION
#define SPI_GETGESTUREVISUALIZATION         0x201A
#endif

#ifndef SPI_GETMOUSEWHEELROUTING
#define SPI_GETMOUSEWHEELROUTING            0x201C
#endif

#ifndef SPI_GETWHEELSCROLLCHARS
#define SPI_GETWHEELSCROLLCHARS             0x006C
#endif

#ifdef __cplusplus
extern "C" {
#endif

SAMPLEDLL3_API BOOL PrintSystemParametersInfo(LPCWSTR lpDisplayName, UINT uiAction);

#ifdef __cplusplus
}
#endif

#endif /* __SAMPLE_DLL_3_H__ */
