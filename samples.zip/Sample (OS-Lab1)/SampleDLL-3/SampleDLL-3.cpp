// SampleDLL-3.cpp
//
// Copyright (c), �.�. ��������� (andrei.glukhoedov@gmail.com)
//

#include <Windows.h>
#include <tchar.h>
#include <stdio.h>

#include "SampleDLL-3.h"

#ifndef CONTACTVISUALIZATION_OFF
#define CONTACTVISUALIZATION_OFF                 0x0000
#endif
#ifndef CONTACTVISUALIZATION_ON
#define CONTACTVISUALIZATION_ON                  0x0001
#endif
#ifndef CONTACTVISUALIZATION_PRESENTATIONMODE
#define CONTACTVISUALIZATION_PRESENTATIONMODE    0x0002
#endif

#ifndef GESTUREVISUALIZATION_OFF
#define GESTUREVISUALIZATION_OFF                 0x0000
#endif
#ifndef GESTUREVISUALIZATION_ON
#define GESTUREVISUALIZATION_ON                  0x001F
#endif

#ifndef MOUSEWHEEL_ROUTING_FOCUS
#define MOUSEWHEEL_ROUTING_FOCUS                  0
#endif
#ifndef MOUSEWHEEL_ROUTING_HYBRID
#define MOUSEWHEEL_ROUTING_HYBRID                 1
#endif
#ifndef MOUSEWHEEL_ROUTING_MOUSE_POS
#define MOUSEWHEEL_ROUTING_MOUSE_POS              2
#endif

// ------------------------------------------------------------------------------------------------
BOOL WINAPI DllMain(HINSTANCE hInstDLL, DWORD dwReason, LPVOID lpvReserved)
{
    return TRUE;
} // DllMain

// ------------------------------------------------------------------------------------------------
SAMPLEDLL3_API BOOL PrintSystemParametersInfo(LPCWSTR lpDisplayName, UINT uiAction)
{
    BOOL bRet = FALSE;

    switch (uiAction)
    {
    case SPI_GETACCESSTIMEOUT:
    {
        ACCESSTIMEOUT at = { sizeof(ACCESSTIMEOUT) };
        bRet = SystemParametersInfo(uiAction, sizeof(ACCESSTIMEOUT), &at, 0);

        if (FALSE != bRet)
        {
            wprintf(L"%s: dwFlags=0x%08X, iTimeOutMSec=%d ms\n", lpDisplayName, at.dwFlags, at.iTimeOutMSec);
        } // if
    }
    break;

    case SPI_GETBEEP:
    case SPI_GETFONTSMOOTHING:
    case SPI_GETDROPSHADOW:
    case SPI_GETFLATMENU:
    case SPI_GETICONTITLEWRAP:
    case SPI_GETKEYBOARDCUES:
    case SPI_GETKEYBOARDPREF:
    case SPI_GETSHOWSOUNDS:
    case SPI_GETSNAPTODEFBUTTON:
    {
        BOOL value;
        bRet = SystemParametersInfo(uiAction, 0, &value, 0);

        if (FALSE != bRet)
        {
            wprintf(L"%s: %s\n", lpDisplayName, ((FALSE != value) ? L"TRUE" : L"FALSE"));
        } // if
    }
    break;

    case SPI_GETCONTACTVISUALIZATION:
    {
        ULONG value;
        bRet = SystemParametersInfo(uiAction, 0, &value, 0);

        if (FALSE != bRet)
        {
            switch (value)
            {
            case CONTACTVISUALIZATION_OFF:
                wprintf(L"%s: OFF\n", lpDisplayName);
                break;

            case CONTACTVISUALIZATION_ON:
                wprintf(L"%s: ON\n", lpDisplayName);
                break;

            case CONTACTVISUALIZATION_PRESENTATIONMODE:
                wprintf(L"%s: PRESENTATIONMODE\n", lpDisplayName);
                break;

            default:
                wprintf(L"%s: %u\n", lpDisplayName, value);
                break;
            } // switch
        } // if
    }
    break;

    case SPI_GETDEFAULTINPUTLANG:
    {
        HKL hkl;
        bRet = SystemParametersInfo(uiAction, 0, &hkl, 0);

        if (FALSE != bRet)
        {
            wprintf(L"%s: %p\n", lpDisplayName, hkl);
        } // if
    }
    break;

    case SPI_GETFOCUSBORDERHEIGHT:
    case SPI_GETFOCUSBORDERWIDTH:
    case SPI_ICONHORIZONTALSPACING:
    case SPI_ICONVERTICALSPACING:
    {
        UINT value;
        bRet = SystemParametersInfo(uiAction, 0, &value, 0);

        if (FALSE != bRet)
        {
            wprintf(L"%s: %u px\n", lpDisplayName, value);
        } // if
    }
    break;

    case SPI_GETGESTUREVISUALIZATION:
    {
        ULONG value;
        bRet = SystemParametersInfo(uiAction, 0, &value, 0);

        if (FALSE != bRet)
        {
            if (value & GESTUREVISUALIZATION_ON)
            {
                wprintf(L"%s: ON\n", lpDisplayName);
            } // if
            else if (GESTUREVISUALIZATION_OFF == value)
            {
                wprintf(L"%s: OFF\n", lpDisplayName);
            } // if
            else
            {
                wprintf(L"%s: %u\n", lpDisplayName, value);
            } // else
        } // if
    }
    break;

    case SPI_GETICONMETRICS:
    {
        ICONMETRICS im = { sizeof(ICONMETRICS) };
        bRet = SystemParametersInfo(uiAction, sizeof(ICONMETRICS), &im, 0);

        if (FALSE != bRet)
        {
            wprintf(L"%s: iHorzSpacing=%d px, iVertSpacing=%d px, iTitleWrap=%d px\n", lpDisplayName, im.iHorzSpacing, im.iVertSpacing, im.iTitleWrap);
        } // if
    }
    break;

    case SPI_GETICONTITLELOGFONT:
    {
        LOGFONT lf;
        bRet = SystemParametersInfo(uiAction, sizeof(LOGFONT), &lf, 0);

        if (FALSE != bRet)
        {
            wprintf(L"%s: lfWeight=%d", lpDisplayName, lf.lfWeight);

            _tprintf(TEXT(", lfFaceName=\"%s\"\n"), lf.lfFaceName);
        } // if
    }
    break;

    case SPI_GETKEYBOARDSPEED:
    {
        DWORD value;
        bRet = SystemParametersInfo(uiAction, 0, &value, 0);

        if (FALSE != bRet)
        {
            wprintf(L"%s: %u rps\n", lpDisplayName, value);
        } // if
    }
    break;

    case SPI_GETMENUSHOWDELAY:
    {
        DWORD value;
        bRet = SystemParametersInfo(uiAction, 0, &value, 0);

        if (FALSE != bRet)
        {
            wprintf(L"%s: %u ms\n", lpDisplayName, value);
        } // if
    }
    break;

    case SPI_GETMINIMIZEDMETRICS:
    {
        MINIMIZEDMETRICS mm = { sizeof(MINIMIZEDMETRICS) };
        bRet = SystemParametersInfo(uiAction, sizeof(MINIMIZEDMETRICS), &mm, 0);

        if (FALSE != bRet)
        {
            wprintf(L"%s: iWidth=%d px, iHorzGap=%d px, iVertGap=%d px", lpDisplayName, mm.iHorzGap, mm.iWidth, mm.iVertGap);

            switch (mm.iArrange & ARW_STARTMASK)
            {
            case ARW_BOTTOMLEFT:
                wprintf(L", iArrange=ARW_BOTTOMLEFT\n");
                break;
            case ARW_BOTTOMRIGHT:
                wprintf(L", iArrange=ARW_BOTTOMRIGHT\n");
                break;
            case ARW_TOPLEFT:
                wprintf(L", iArrange=ARW_TOPLEFT\n");
                break;
            case ARW_TOPRIGHT:
                wprintf(L", iArrange=ARW_TOPRIGHT\n");
                break;
            } // switch
        } // if
    }
    break;

    case SPI_GETMOUSE:
    {
        int aMouseInfo[3];
        bRet = SystemParametersInfo(uiAction, 0, aMouseInfo, 0);

        if (FALSE != bRet)
        {
            wprintf(L"%s: { %d, %d, %d }\n", lpDisplayName, aMouseInfo[0], aMouseInfo[1], aMouseInfo[2]);
        } // if
    }
    break;

    case SPI_GETMOUSEKEYS:
    {
        MOUSEKEYS mk = { sizeof(MOUSEKEYS) };
        bRet = SystemParametersInfo(uiAction, sizeof(MOUSEKEYS), &mk, 0);

        if (FALSE != bRet)
        {
            wprintf(L"%s: dwFlags=0x%08X, iMaxSpeed=%d, iTimeToMaxSpeed=%d ms, iCtrlSpeed=%d\n", lpDisplayName, mk.dwFlags, mk.iMaxSpeed, mk.iTimeToMaxSpeed, mk.iCtrlSpeed);
        } // if
    }
    break;

    case SPI_GETMOUSEWHEELROUTING:
    {
        DWORD value;
        bRet = SystemParametersInfo(uiAction, 0, &value, 0);

        if (FALSE != bRet)
        {
            switch (value)
            {
            case MOUSEWHEEL_ROUTING_FOCUS:
                wprintf(L"%s: MOUSEWHEEL_ROUTING_FOCUS\n", lpDisplayName);
                break;
            case MOUSEWHEEL_ROUTING_HYBRID:
                wprintf(L"%s: MOUSEWHEEL_ROUTING_HYBRID\n", lpDisplayName);
                break;
            case MOUSEWHEEL_ROUTING_MOUSE_POS:
                wprintf(L"%s: MOUSEWHEEL_ROUTING_MOUSE_POS\n", lpDisplayName);
                break;
            default:
                wprintf(L"%s: %u\n", lpDisplayName, value);
                break;
            } // switch
        } // if
    }
    break;

    case SPI_GETSERIALKEYS:
    {
        wprintf(L"%s: ���� �������� �� ��������������\n", lpDisplayName);
    }
    break;

    case SPI_GETSOUNDSENTRY:
    {
        SOUNDSENTRY ss = { sizeof(SOUNDSENTRY) };
        bRet = SystemParametersInfo(uiAction, sizeof(SOUNDSENTRY), &ss, 0);

        if (FALSE != bRet)
        {
            wprintf(L"%s: dwFlags=0x%08X", lpDisplayName);

            switch (ss.iWindowsEffect)
            {
            case SSWF_CUSTOM:
                wprintf(L", iWindowsEffect=SSWF_CUSTOM\n");
                break;
            case SSWF_DISPLAY:
                wprintf(L", iWindowsEffect=SSWF_DISPLAY\n");
                break;
            case SSWF_NONE:
                wprintf(L", iWindowsEffect=SSWF_NONE\n");
                break;
            case SSWF_TITLE:
                wprintf(L", iWindowsEffect=SSWF_TITLE\n");
                break;
            case SSWF_WINDOW:
                wprintf(L", iWindowsEffect=SSWF_WINDOW\n");
                break;
            default:
                wprintf(L", iWindowsEffect=%u\n", ss.iWindowsEffect);
                break;
            } // switch
        } // if
    }
    break;

    case SPI_GETWHEELSCROLLCHARS:
    {
        UINT value;
        bRet = SystemParametersInfo(uiAction, 0, &value, 0);

        if (FALSE != bRet)
        {
            wprintf(L"%s: %u char(s)\n", lpDisplayName, value);
        } // if
    }
    break;

    case SPI_GETWHEELSCROLLLINES:
    {
        UINT value;
        bRet = SystemParametersInfo(uiAction, 0, &value, 0);

        if (FALSE != bRet)
        {
            wprintf(L"%s: %u line(s)\n", lpDisplayName, value);
        } // if
    }
    break;

    case SPI_GETWORKAREA:
    {
        RECT rcWorkArea;
        bRet = SystemParametersInfo(uiAction, 0, &rcWorkArea, 0);

        if (FALSE != bRet)
        {
            wprintf(L"%s: %d x %d\n", lpDisplayName, (rcWorkArea.right - rcWorkArea.left), (rcWorkArea.bottom - rcWorkArea.top));
        } // if
    }
    break;
    } // switch

    return bRet;
} // PrintSystemParametersInfo
