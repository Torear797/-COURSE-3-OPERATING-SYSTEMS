// SampleDLL-2.cpp
//
// Copyright (c), �.�. ��������� (andrei.glukhoedov@gmail.com)
//

#include <Windows.h>
#include <stdio.h>

#define SAMPLEDLL2_PROTOTYPES
#include "SampleDLL-2.h"

// ------------------------------------------------------------------------------------------------
BOOL WINAPI DllMain(HINSTANCE hInstDLL, DWORD dwReason, LPVOID lpvReserved)
{
    return TRUE;
} // DllMain

// ------------------------------------------------------------------------------------------------
SAMPLEDLL2_API void PrintSystemMetrics(LPCWSTR lpDisplayName, int nIndex)
{
    int value = GetSystemMetrics(nIndex); // ������� �������� ��������� �������

    switch (nIndex)
    {
    case SM_ARRANGE:
        switch (value & ARW_STARTMASK)
        {
        case ARW_BOTTOMLEFT:
            wprintf(L"%s: ARW_BOTTOMLEFT\n", lpDisplayName);
            break;
        case ARW_BOTTOMRIGHT:
            wprintf(L"%s: ARW_BOTTOMRIGHT\n", lpDisplayName);
            break;
        case ARW_TOPLEFT:
            wprintf(L"%s: ARW_TOPLEFT\n", lpDisplayName);
            break;
        case ARW_TOPRIGHT:
            wprintf(L"%s: ARW_TOPRIGHT\n", lpDisplayName);
            break;
        } // switch
        break;

    case SM_CLEANBOOT:
        switch (value)
        {
        case 0:
            wprintf(L"%s: Normal boot\n", lpDisplayName);
            break;
        case 1:
            wprintf(L"%s: Fail-safe boot\n", lpDisplayName);
            break;
        case 2:
            wprintf(L"%s: Fail-safe with network boot\n", lpDisplayName);
            break;
        default:
            wprintf(L"%s: %d\n", lpDisplayName, value);
            break;
        } // switch
        break;

    case SM_CXBORDER:
    case SM_CXCURSOR:
    case SM_CXDLGFRAME:
    case SM_CXDOUBLECLK:
    case SM_CXDRAG:
    case SM_CXEDGE:
    case SM_CXFOCUSBORDER:
    case SM_CXFRAME:
    case SM_CXFULLSCREEN:
    case SM_CXHSCROLL:
    case SM_CXHTHUMB:
    case SM_CXICON:
    case SM_CXICONSPACING:
    case SM_CXMAXIMIZED:
    case SM_CXMAXTRACK:
    case SM_CXMENUCHECK:
    case SM_CXMENUSIZE:
    case SM_CXMIN:
    case SM_CXMINIMIZED:
    case SM_CXMINSPACING:
    case SM_CXMINTRACK:
    case SM_CXPADDEDBORDER:
    case SM_CXSCREEN:
    case SM_CXSIZE:
    case SM_CXSMICON:
    case SM_CXSMSIZE:
    case SM_CXVIRTUALSCREEN:
    case SM_CXVSCROLL:
    case SM_CYBORDER:
    case SM_CYCAPTION:
    case SM_CYCURSOR:
    case SM_CYDLGFRAME:
    case SM_CYDOUBLECLK:
    case SM_CYDRAG:
    case SM_CYEDGE:
    case SM_CYFOCUSBORDER:
    case SM_CYFRAME:
    case SM_CYFULLSCREEN:
    case SM_CYHSCROLL:
    case SM_CYICON:
    case SM_CYICONSPACING:
    case SM_CYMAXIMIZED:
    case SM_CYMAXTRACK:
    case SM_CYMENU:
    case SM_CYMENUCHECK:
    case SM_CYMENUSIZE:
    case SM_CYMIN:
    case SM_CYMINIMIZED:
    case SM_CYMINSPACING:
    case SM_CYMINTRACK:
    case SM_CYSCREEN:
    case SM_CYSIZE:
    case SM_CYSMCAPTION:
    case SM_CYSMICON:
    case SM_CYSMSIZE:
    case SM_CYVIRTUALSCREEN:
    case SM_CYVSCROLL:
    case SM_CYVTHUMB:
        wprintf(L"%s: %d px\n", lpDisplayName, value);
        break;

    case SM_CMONITORS:
    case SM_CMOUSEBUTTONS:
    case SM_MEDIACENTER:
    case SM_MIDEASTENABLED:
    case SM_MOUSEPRESENT:
    case SM_MOUSEWHEELPRESENT:
    case SM_NETWORK:
    case SM_REMOTECONTROL:
    case SM_REMOTESESSION:
    case SM_SHOWSOUNDS:
    case SM_STARTER:
    default:
        wprintf(L"%s: %d\n", lpDisplayName, value);
        break;
    } // switch
} // PrintSystemMetrics
