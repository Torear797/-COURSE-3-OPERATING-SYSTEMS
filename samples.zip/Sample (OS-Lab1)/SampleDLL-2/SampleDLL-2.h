// SampleDLL-2.h
//
// Copyright (c), �.�. ��������� (andrei.glukhoedov@gmail.com)
//

#pragma once

#if !defined(__SAMPLE_DLL_2_H__)
#define __SAMPLE_DLL_2_H__

#ifdef SAMPLEDLL2_EXPORTS
#define SAMPLEDLL2_API __declspec(dllexport)
#else
#define SAMPLEDLL2_API __declspec(dllimport)
#endif

#ifndef SM_CXFOCUSBORDER
#define SM_CXFOCUSBORDER        83
#endif

#ifndef SM_CYFOCUSBORDER
#define SM_CYFOCUSBORDER        84
#endif

#ifndef SM_CXPADDEDBORDER
#define SM_CXPADDEDBORDER       92
#endif

typedef void (*PRINT_SYSTEMMETRICS_PROC)(LPCWSTR lpDisplayName, int nIndex);


#ifdef SAMPLEDLL2_PROTOTYPES

#ifdef __cplusplus
extern "C" {
#endif

SAMPLEDLL2_API void PrintSystemMetrics(LPCWSTR lpDisplayName, int nIndex);

#ifdef __cplusplus
}
#endif

#endif /* SAMPLEDLL2_PROTOTYPES */


#endif /* __SAMPLE_DLL_2_H__ */
