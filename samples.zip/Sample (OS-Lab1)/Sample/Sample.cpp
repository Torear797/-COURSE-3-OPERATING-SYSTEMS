// Sample.cpp
//
// Copyright (c), �.�. ��������� (andrei.glukhoedov@gmail.com)
//

#include <Windows.h>
#include <tchar.h>
#include <stdio.h>
#include <locale.h>
#include <delayimp.h>

#include <SampleLibrary.h>
#include <SampleDLL-1.h>
#include <SampleDLL-2.h>
#include <SampleDLL-3.h>

int _tmain()
{
    _tsetlocale(LC_ALL, TEXT(""));

    // SampleLibrary.lib //

    _tprintf(TEXT("��� ��������� � ������������:\n"));

    // ������� NetBIOS ��� ����������
    PrintComputerName();
    // ������� DNS ��� ����������
    PrintDNSHostname();

    // ������� ��� �������� ������������
    PrintUserName();
    // ������� ������ ��� �������� ������������
    PrintUserNameCompatible();

    // SampleDLL-1.dll //

    // ������� ������ ��������� ����������

    _tprintf(TEXT("\n��������� ����������:\n"));

    // ������ ��������������� ��������� ���������
    const long csidl[] = {
        CSIDL_APPDATA,
        CSIDL_COMMON_APPDATA,
        CSIDL_COMMON_DOCUMENTS,
        CSIDL_HISTORY,
        CSIDL_INTERNET_CACHE,
        CSIDL_LOCAL_APPDATA,
        CSIDL_PERSONAL,
        CSIDL_PROGRAM_FILES,
        CSIDL_PROGRAM_FILES_COMMON,
        CSIDL_SYSTEM,
        CSIDL_WINDOWS
    };

    PrintSysDirectories(csidl, _countof(csidl));

    // ������� ������ Windows

    _tprintf(TEXT("\n������ Windows:\n"));

    PrintOSVersionInfo();

    // ������� ���� � �����

    _tprintf(TEXT("\n���� � �����:\n"));

    SYSTEMTIME st;
    GetLocalTime(&st);

    PrintDataTime(LOCALE_NAME_INVARIANT, &st, NULL, NULL);
    PrintDataTime(LOCALE_NAME_SYSTEM_DEFAULT, &st, NULL, NULL);
    PrintDataTime(LOCALE_NAME_USER_DEFAULT, &st, NULL, NULL);

    PrintDataTime(LOCALE_NAME_INVARIANT, &st, L"yyyy.MM.dd", L"hh:mm tt");
    PrintDataTime(LOCALE_NAME_INVARIANT, &st, L"yyyy-MM-dd", L"hh:mm:ss tt");
    PrintDataTime(LOCALE_NAME_INVARIANT, &st, L"yyyy/MM/dd", L"h:m t");
    PrintDataTime(LOCALE_NAME_INVARIANT, &st, L"yyyy-M-d", L"h:m:s t");
    PrintDataTime(LOCALE_NAME_INVARIANT, &st, L"yyyy/M/d", L"HH:mm");
    PrintDataTime(LOCALE_NAME_INVARIANT, &st, L"d.M.yyyy", L"HH:mm:ss");
    PrintDataTime(LOCALE_NAME_INVARIANT, &st, L"d-M-yyyy", L"H:m");
    PrintDataTime(LOCALE_NAME_INVARIANT, &st, L"d/M/yyyy", L"H:m:s");
    PrintDataTime(LOCALE_NAME_INVARIANT, &st, L"dd.MM.yyyy", L"hh:mm tt");
    PrintDataTime(LOCALE_NAME_INVARIANT, &st, L"dd-MM-yyyy", L"hh:mm:ss tt");
    PrintDataTime(LOCALE_NAME_INVARIANT, &st, L"dd/MM/yyyy", L"h:m t");
    PrintDataTime(LOCALE_NAME_INVARIANT, &st, L"MM/dd/yyyy", L"h:m:s t");
    PrintDataTime(LOCALE_NAME_INVARIANT, &st, L"M/d/yyyy", L"HH:mm");
    PrintDataTime(LOCALE_NAME_USER_DEFAULT, &st, L"d MMMM yyyy", L"HH:mm:ss");
    PrintDataTime(LOCALE_NAME_USER_DEFAULT, &st, L"d MMM yyyy", L"H:m");

    // SampleDLL-2.dll //

    _tprintf(TEXT("\n��������� �������:\n"));

    HMODULE hDLL = LoadLibrary(TEXT("SampleDLL-2.dll")); // ��������� ���������� SampleDLL-2.dll

    if (NULL != hDLL)
    {
        PRINT_SYSTEMMETRICS_PROC PrintSystemMetrics = (PRINT_SYSTEMMETRICS_PROC)GetProcAddress(hDLL, "PrintSystemMetrics");

        if (NULL != PrintSystemMetrics)
        {
            PrintSystemMetrics(L"SM_ARRANGE", SM_ARRANGE);
            PrintSystemMetrics(L"SM_CLEANBOOT", SM_CLEANBOOT);
            PrintSystemMetrics(L"SM_CMONITORS", SM_CMONITORS);
            PrintSystemMetrics(L"SM_CMOUSEBUTTONS", SM_CMOUSEBUTTONS);
            PrintSystemMetrics(L"SM_CXBORDER", SM_CXBORDER);
            PrintSystemMetrics(L"SM_CXCURSOR", SM_CXCURSOR);
            PrintSystemMetrics(L"SM_CXDLGFRAME", SM_CXDLGFRAME);
            PrintSystemMetrics(L"SM_CXDOUBLECLK", SM_CXDOUBLECLK);
            PrintSystemMetrics(L"SM_CXDRAG", SM_CXDRAG);
            PrintSystemMetrics(L"SM_CXEDGE", SM_CXEDGE);
            PrintSystemMetrics(L"SM_CXFIXEDFRAME", SM_CXFIXEDFRAME);
            PrintSystemMetrics(L"SM_CXFOCUSBORDER", SM_CXFOCUSBORDER);
            PrintSystemMetrics(L"SM_CXFRAME", SM_CXFRAME);
            PrintSystemMetrics(L"SM_CXFULLSCREEN", SM_CXFULLSCREEN);
            PrintSystemMetrics(L"SM_CXHSCROLL", SM_CXHSCROLL);
            PrintSystemMetrics(L"SM_CXHTHUMB", SM_CXHTHUMB);
            PrintSystemMetrics(L"SM_CXICON", SM_CXICON);
            PrintSystemMetrics(L"SM_CXICONSPACING", SM_CXICONSPACING);
            PrintSystemMetrics(L"SM_CXMAXIMIZED", SM_CXMAXIMIZED);
            PrintSystemMetrics(L"SM_CXMAXTRACK", SM_CXMAXTRACK);
            PrintSystemMetrics(L"SM_CXMENUCHECK", SM_CXMENUCHECK);
            PrintSystemMetrics(L"SM_CXMENUSIZE", SM_CXMENUSIZE);
            PrintSystemMetrics(L"SM_CXMIN", SM_CXMIN);
            PrintSystemMetrics(L"SM_CXMINIMIZED", SM_CXMINIMIZED);
            PrintSystemMetrics(L"SM_CXMINSPACING", SM_CXMINSPACING);
            PrintSystemMetrics(L"SM_CXMINTRACK", SM_CXMINTRACK);
            PrintSystemMetrics(L"SM_CXPADDEDBORDER", SM_CXPADDEDBORDER);
            PrintSystemMetrics(L"SM_CXSCREEN", SM_CXSCREEN);
            PrintSystemMetrics(L"SM_CXSIZE", SM_CXSIZE);
            PrintSystemMetrics(L"SM_CXSIZEFRAME", SM_CXSIZEFRAME);
            PrintSystemMetrics(L"SM_CXSMICON", SM_CXSMICON);
            PrintSystemMetrics(L"SM_CXSMSIZE", SM_CXSMSIZE);
            PrintSystemMetrics(L"SM_CXVIRTUALSCREEN", SM_CXVIRTUALSCREEN);
            PrintSystemMetrics(L"SM_CXVSCROLL", SM_CXVSCROLL);
            PrintSystemMetrics(L"SM_CYBORDER", SM_CYBORDER);
            PrintSystemMetrics(L"SM_CYCAPTION", SM_CYCAPTION);
            PrintSystemMetrics(L"SM_CYCURSOR", SM_CYCURSOR);
            PrintSystemMetrics(L"SM_CYDLGFRAME", SM_CYDLGFRAME);
            PrintSystemMetrics(L"SM_CYDOUBLECLK", SM_CYDOUBLECLK);
            PrintSystemMetrics(L"SM_CYDRAG", SM_CYDRAG);
            PrintSystemMetrics(L"SM_CYEDGE", SM_CYEDGE);
            PrintSystemMetrics(L"SM_CYFIXEDFRAME", SM_CYFIXEDFRAME);
            PrintSystemMetrics(L"SM_CYFOCUSBORDER", SM_CYFOCUSBORDER);
            PrintSystemMetrics(L"SM_CYFRAME", SM_CYFRAME);
            PrintSystemMetrics(L"SM_CYFULLSCREEN", SM_CYFULLSCREEN);
            PrintSystemMetrics(L"SM_CYHSCROLL", SM_CYHSCROLL);
            PrintSystemMetrics(L"SM_CYICON", SM_CYICON);
            PrintSystemMetrics(L"SM_CYICONSPACING", SM_CYICONSPACING);
            PrintSystemMetrics(L"SM_CYMAXIMIZED", SM_CYMAXIMIZED);
            PrintSystemMetrics(L"SM_CYMAXTRACK", SM_CYMAXTRACK);
            PrintSystemMetrics(L"SM_CYMENU", SM_CYMENU);
            PrintSystemMetrics(L"SM_CYMENUCHECK", SM_CYMENUCHECK);
            PrintSystemMetrics(L"SM_CYMENUSIZE", SM_CYMENUSIZE);
            PrintSystemMetrics(L"SM_CYMIN", SM_CYMIN);
            PrintSystemMetrics(L"SM_CYMINIMIZED", SM_CYMINIMIZED);
            PrintSystemMetrics(L"SM_CYMINSPACING", SM_CYMINSPACING);
            PrintSystemMetrics(L"SM_CYMINTRACK", SM_CYMINTRACK);
            PrintSystemMetrics(L"SM_CYSCREEN", SM_CYSCREEN);
            PrintSystemMetrics(L"SM_CYSIZE", SM_CYSIZE);
            PrintSystemMetrics(L"SM_CYSIZEFRAME", SM_CYSIZEFRAME);
            PrintSystemMetrics(L"SM_CYSMCAPTION", SM_CYSMCAPTION);
            PrintSystemMetrics(L"SM_CYSMICON", SM_CYSMICON);
            PrintSystemMetrics(L"SM_CYSMSIZE", SM_CYSMSIZE);
            PrintSystemMetrics(L"SM_CYVIRTUALSCREEN", SM_CYVIRTUALSCREEN);
            PrintSystemMetrics(L"SM_CYVSCROLL", SM_CYVSCROLL);
            PrintSystemMetrics(L"SM_CYVTHUMB", SM_CYVTHUMB);
            PrintSystemMetrics(L"SM_MEDIACENTER", SM_MEDIACENTER);
            PrintSystemMetrics(L"SM_MIDEASTENABLED", SM_MIDEASTENABLED);
            PrintSystemMetrics(L"SM_MOUSEPRESENT", SM_MOUSEPRESENT);
            PrintSystemMetrics(L"SM_MOUSEWHEELPRESENT", SM_MOUSEWHEELPRESENT);
            PrintSystemMetrics(L"SM_NETWORK", SM_NETWORK);
            PrintSystemMetrics(L"SM_REMOTECONTROL", SM_REMOTECONTROL);
            PrintSystemMetrics(L"SM_REMOTESESSION", SM_REMOTESESSION);
            PrintSystemMetrics(L"SM_SHOWSOUNDS", SM_SHOWSOUNDS);
            PrintSystemMetrics(L"SM_STARTER", SM_STARTER);
        } // if
        else
        {
            _tprintf(TEXT("������: %d, ������� PrintSystemMetrics �� �������\n"), GetLastError());
        } // else

        FreeLibrary(hDLL);
    } // if
    else
    {
        _tprintf(TEXT("������: %d, SampleDLL-2.dll �� �������\n"), GetLastError());
    } // else

    // SampleDLL-3.dll //

    _tprintf(TEXT("\n��������� ���������:\n"));

    __try
    {
        PrintSystemParametersInfo(L"SPI_GETACCESSTIMEOUT", SPI_GETACCESSTIMEOUT);
        PrintSystemParametersInfo(L"SPI_GETBEEP", SPI_GETBEEP);
        PrintSystemParametersInfo(L"SPI_GETCONTACTVISUALIZATION", SPI_GETCONTACTVISUALIZATION);
        PrintSystemParametersInfo(L"SPI_GETDEFAULTINPUTLANG", SPI_GETDEFAULTINPUTLANG);
        PrintSystemParametersInfo(L"SPI_GETDROPSHADOW", SPI_GETDROPSHADOW);
        PrintSystemParametersInfo(L"SPI_GETFLATMENU", SPI_GETFLATMENU);
        PrintSystemParametersInfo(L"SPI_GETFOCUSBORDERHEIGHT", SPI_GETFOCUSBORDERHEIGHT);
        PrintSystemParametersInfo(L"SPI_GETFOCUSBORDERWIDTH", SPI_GETFOCUSBORDERWIDTH);
        PrintSystemParametersInfo(L"SPI_GETFONTSMOOTHING", SPI_GETFONTSMOOTHING);
        PrintSystemParametersInfo(L"SPI_GETGESTUREVISUALIZATION", SPI_GETGESTUREVISUALIZATION);
        PrintSystemParametersInfo(L"SPI_GETICONMETRICS", SPI_GETICONMETRICS);
        PrintSystemParametersInfo(L"SPI_GETICONTITLELOGFONT", SPI_GETICONTITLELOGFONT);
        PrintSystemParametersInfo(L"SPI_GETICONTITLEWRAP", SPI_GETICONTITLEWRAP);
        PrintSystemParametersInfo(L"SPI_GETKEYBOARDCUES", SPI_GETKEYBOARDCUES);
        PrintSystemParametersInfo(L"SPI_GETKEYBOARDPREF", SPI_GETKEYBOARDPREF);
        PrintSystemParametersInfo(L"SPI_GETKEYBOARDSPEED", SPI_GETKEYBOARDSPEED);
        PrintSystemParametersInfo(L"SPI_GETMENUSHOWDELAY", SPI_GETMENUSHOWDELAY);
        PrintSystemParametersInfo(L"SPI_GETMINIMIZEDMETRICS", SPI_GETMINIMIZEDMETRICS);
        PrintSystemParametersInfo(L"SPI_GETMOUSE", SPI_GETMOUSE);
        PrintSystemParametersInfo(L"SPI_GETMOUSEKEYS", SPI_GETMOUSEKEYS);
        PrintSystemParametersInfo(L"SPI_GETMOUSEWHEELROUTING", SPI_GETMOUSEWHEELROUTING);
        PrintSystemParametersInfo(L"SPI_GETSERIALKEYS", SPI_GETSERIALKEYS);
        PrintSystemParametersInfo(L"SPI_GETSHOWSOUNDS", SPI_GETSHOWSOUNDS);
        PrintSystemParametersInfo(L"SPI_GETSNAPTODEFBUTTON", SPI_GETSNAPTODEFBUTTON);
        PrintSystemParametersInfo(L"SPI_GETSOUNDSENTRY", SPI_GETSOUNDSENTRY);
        PrintSystemParametersInfo(L"SPI_GETWHEELSCROLLCHARS", SPI_GETWHEELSCROLLCHARS);
        PrintSystemParametersInfo(L"SPI_GETWHEELSCROLLLINES", SPI_GETWHEELSCROLLLINES);
        PrintSystemParametersInfo(L"SPI_GETWORKAREA", SPI_GETWORKAREA);
        PrintSystemParametersInfo(L"SPI_ICONHORIZONTALSPACING", SPI_ICONHORIZONTALSPACING);
        PrintSystemParametersInfo(L"SPI_ICONVERTICALSPACING", SPI_ICONVERTICALSPACING);
    } // __try
    __except (EXCEPTION_EXECUTE_HANDLER)
    {
        switch (GetLastError())
        {
        case ERROR_MOD_NOT_FOUND:
            _tprintf(TEXT("������:  %d, SampleDLL-3.dll �� �������\n"), ERROR_MOD_NOT_FOUND);
            break;
        case ERROR_PROC_NOT_FOUND:
            _tprintf(TEXT("������:  %d, ������� PrintSystemParametersInfo �� �������\n"), ERROR_PROC_NOT_FOUND);
            break;
        } // switch
    } // __except

    __FUnloadDelayLoadedDLL2("SampleDLL-3.dll"); // ��������� ��������� SampleDLL-3.dll
} // _tmain
